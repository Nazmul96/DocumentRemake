<?php

namespace App\Http\Controllers\Pdf;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use File;
use Image;
use App\Models\GlovalSetting;

class SettingsController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function glovalSetting()
    {
       return view('/admin/pdf-setting/gloval-setting');
    }

    public function saveGlovalSetting(Request $request)
    {
        // $validatedData = $request->validate([
        //     'brand_name' => 'required',
        //     'status' => 'required',
        // ]);

        //echo "<pre>";print_r($request->word_name);die();

        if(count($request->word_name)>0){

            foreach($request->word_name as $key=>$word_name){
                $glovalSetting = new GlovalSetting();  
                $glovalSetting->name = $word_name;
                $glovalSetting->value = $request->word_value[$key];
                $glovalSetting->type = $request->type[$key];
                $glovalSetting->save();
            }

        }

        return redirect()->route('Pdf.gloval-setting-list.glovalSettingList')->with('message', 'Words value Stored successfully.');

    }

    public function glovalSettingList()
    {
        $Words_details = GlovalSetting::get()->toArray();
        // echo "<pre>";print_r($Words_details);die();
        return view('/admin/pdf-setting/gloval-setting-list')->with('words_details', $Words_details);
    }

    public function updateGlovalSetting(Request $request)
    {
        // $validatedData = $request->validate([
        //     'brand_name' => 'required',
        //     'status' => 'required',
        // ]);

        // echo "<pre>";print_r($request->word_name);die();
        $error = array();
        if(count($request->ids)>0){
            
            
            foreach($request->ids as $key=>$id){

                $error_chk = 
                $glovalSetting = GlovalSetting::find($id);
                $glovalSetting->name = $request->word_name[$key];
                $glovalSetting->value = $request->word_value[$key];
                $glovalSetting->type = $request->type[$key];
                $glovalSetting->update();
            }
        }

        return redirect()->route('Pdf.gloval-setting-list.glovalSettingList')->with('message', 'Words value Stored successfully.');

    }

}
